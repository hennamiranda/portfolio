document.onload = () => {
    const openMenuButton = document.querySelector('#button-open');
    const closeMenuButton = document.querySelector('#button-close');
    const nav = document.querySelector('nav');
  
    openMenuButton.addEventListener('click', () => {
      nav.setAttribute('class', 'open');
    });
  
    closeMenuButton.addEventListener('click', () => {
      nav.setAttribute('class', 'close');
    });
  };